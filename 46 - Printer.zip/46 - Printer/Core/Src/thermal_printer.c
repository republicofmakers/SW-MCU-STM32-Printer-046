/*
 * thermal_printer.c
 *
 *  Created on: Apr 26, 2025
 *      Author: ceyhun
 */


#include "thermal_printer.h"

#define PRINTER_UART &huart1
#define PRINTER_TIMEOUT 100

static void Printer_SendByte(uint8_t b) {
    HAL_UART_Transmit(PRINTER_UART, &b, 1, PRINTER_TIMEOUT);
}

static void Printer_SendCommand(uint8_t a, uint8_t b, uint8_t c) {
    Printer_SendByte(27); // ESC
    Printer_SendByte(a);
    Printer_SendByte(b);
    Printer_SendByte(c);
}

void Printer_Begin(void) {
    HAL_Delay(500); // Give printer some time after power-up
    // Reset Printer
    Printer_SendByte(27);
    Printer_SendByte('@');
}

void Printer_PrintText(const char* text) {
    while (*text) {
        Printer_SendByte(*text++);
    }
    Printer_SendByte('\n');
}

void Printer_PrintBarcode(const char* text) {
    Printer_SendByte(29); // GS
    Printer_SendByte('H'); // Print barcode label below
    Printer_SendByte(2);   // 2 = Print label below the barcode

    Printer_SendByte(29); // GS
    Printer_SendByte('h'); // Set barcode height
    Printer_SendByte(80);  // Height in dots (try 80 for better visibility)

    Printer_SendByte(29); // GS
    Printer_SendByte('k'); // Start barcode
    Printer_SendByte(4);   // CODE39

    // Send text
    while (*text) {
        Printer_SendByte(*text++);
    }

    Printer_SendByte(0x00); // NULL terminator is required
}

void Printer_PrintBitmap(const uint8_t* bitmap, uint16_t w, uint16_t h) {
    uint16_t rowBytes = (w + 7) / 8;
    uint32_t dataLen = rowBytes * h;

    uint8_t xL = rowBytes & 0xFF;
    uint8_t xH = (rowBytes >> 8) & 0xFF;
    uint8_t yL = h & 0xFF;
    uint8_t yH = (h >> 8) & 0xFF;

    // Raster bit image command
    Printer_SendByte(0x1D); // GS
    Printer_SendByte('v');  // 'v'
    Printer_SendByte('0');  // '0'
    Printer_SendByte(0x00); // Normal mode

    Printer_SendByte(xL);
    Printer_SendByte(xH);
    Printer_SendByte(yL);
    Printer_SendByte(yH);

    for (uint32_t i = 0; i < dataLen; i++) {
        Printer_SendByte(bitmap[i]);
    }

    Printer_SendByte('\n'); // Line feed
}
