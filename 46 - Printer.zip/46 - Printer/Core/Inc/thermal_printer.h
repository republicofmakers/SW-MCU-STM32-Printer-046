#ifndef THERMAL_PRINTER_H
#define THERMAL_PRINTER_H

#include "stm32f1xx_hal.h"

extern UART_HandleTypeDef huart1; // Change this to your UART if not USART1

void Printer_Begin(void);
void Printer_PrintText(const char* text);
void Printer_PrintBarcode(const char* text);
void Printer_PrintBitmap(const uint8_t* bitmap, uint16_t w, uint16_t h);

#endif
